// Screen Ask hotkey: press § to start a screen selection, press § again to cancel it.
// The § key press is swallowed, so it won't type "§" into other apps while this runs.
// Stop with Ctrl+C in the terminal where it runs.

import Cocoa
import ApplicationServices

let script = NSString(string: "~/Tools/screen-ask/screen-ask.sh").expandingTildeInPath
var tap: CFMachPort?

func toggle() {
    // If a selection crosshair is active, cancel it.
    let pkill = Process()
    pkill.executableURL = URL(fileURLWithPath: "/usr/bin/pkill")
    pkill.arguments = ["-x", "screencapture"]
    try? pkill.run()
    pkill.waitUntilExit()
    if pkill.terminationStatus == 0 {
        print("§ → cancelled")
        return
    }
    // Otherwise start a new capture + ask.
    let p = Process()
    p.executableURL = URL(fileURLWithPath: "/bin/zsh")
    p.arguments = [script]
    do { try p.run(); print("§ → selecting…") } catch { print("Could not start script: \(error)") }
}

func isSectionKey(_ event: CGEvent) -> Bool {
    let mods: CGEventFlags = [.maskCommand, .maskControl, .maskAlternate, .maskShift]
    if !event.flags.intersection(mods).isEmpty { return false }
    var length = 0
    var chars = [UniChar](repeating: 0, count: 4)
    event.keyboardGetUnicodeString(maxStringLength: 4, actualStringLength: &length, unicodeString: &chars)
    return String(utf16CodeUnits: chars, count: length) == "§"
}

let callback: CGEventTapCallBack = { _, type, event, _ in
    if type == .tapDisabledByTimeout || type == .tapDisabledByUserInput {
        if let t = tap { CGEvent.tapEnable(tap: t, enable: true) }
        return Unmanaged.passUnretained(event)
    }
    if (type == .keyDown || type == .keyUp) && isSectionKey(event) {
        if type == .keyDown && event.getIntegerValueField(.keyboardEventAutorepeat) == 0 {
            DispatchQueue.main.async { toggle() }
        }
        return nil  // swallow the key
    }
    return Unmanaged.passUnretained(event)
}

// Listening to the keyboard needs Accessibility permission.
let opts = [kAXTrustedCheckOptionPrompt.takeUnretainedValue() as String: true] as CFDictionary
if !AXIsProcessTrustedWithOptions(opts) {
    print("""
    Needs Accessibility permission.
    Open System Settings → Privacy & Security → Accessibility, enable the app you run this from
    (e.g. Terminal), then start this again.
    """)
    exit(1)
}

let mask = (1 << CGEventType.keyDown.rawValue) | (1 << CGEventType.keyUp.rawValue)
guard let t = CGEvent.tapCreate(tap: .cgSessionEventTap, place: .headInsertEventTap,
                                options: .defaultTap, eventsOfInterest: CGEventMask(mask),
                                callback: callback, userInfo: nil) else {
    print("Could not listen to the keyboard. Check Accessibility permission.")
    exit(1)
}
tap = t
let source = CFMachPortCreateRunLoopSource(kCFAllocatorDefault, t, 0)
CFRunLoopAddSource(CFRunLoopGetCurrent(), source, .commonModes)
CGEvent.tapEnable(tap: t, enable: true)
print("Screen Ask is running. Press § to select an area, § again to cancel. Ctrl+C to quit.")
CFRunLoopRun()
