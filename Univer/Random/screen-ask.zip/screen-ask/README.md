# Screen Ask

Press **§**, select part of your screen, and get Claude's answer as a notification.
All screenshots and messages go to **one ongoing Claude session**, so it remembers
your reference documents and earlier questions.

It uses the Claude Code CLI with your Claude Pro account (no API key, no extra cost,
but it counts toward your Pro usage limits).

---

## Quick start (every time)

Open Terminal and go to this folder:

```
cd ~/Tools/screen-ask
```

1. **(Optional) Give it instructions or documents.** Skip this if the session already has them.
   ```
   ./tell "Read all documents in docs and use them as your primary reference."
   ```
2. **Start the § hotkey** and leave this Terminal window open:
   ```
   ./screen-ask-hotkey
   ```
3. **Use it:**
   - Press **§**: the cursor becomes a crosshair.
   - Drag over the area you want (or press **Space** and click a window to capture it).
   - Press **§** again (or **Esc**) to cancel without sending anything.
   - You'll see a "Thinking…" notification, then a notification with the answer
     (usually 10–30 seconds).
   - The full answer is also **copied to your clipboard**, so press ⌘V to see all of it.
4. **To stop:** press **Ctrl+C** in the Terminal window running the hotkey.

To send more messages while the hotkey is running, open a **second Terminal tab**
(⌘T), `cd ~/Tools/screen-ask`, and use `./tell` there.

---

## How the session works

- **There's no separate "start session" step.** The session is created by the first
  message you send, whether that's a `./tell` message or a screenshot.
- After that, every `./tell` and every screenshot goes to **the same session**, even after
  you quit the hotkey or restart your Mac. It continues until you reset it.
- The session ID is stored in `workspace/.session-id`.

### Starting over

```
./tell --new                                    # forget everything
./tell --new "Read all documents in docs and use them as your primary reference."
                                                # forget everything and start with a message
```

Start over when you change subject or documents, or when answers start getting worse.
Very long sessions get summarized automatically, so details can get lost.

---

## Reference documents

Put files in:

```
~/Tools/screen-ask/workspace/docs/
```

PDF, txt, md, code files and images all work. Then tell the session to read them:

```
./tell "Read all documents in docs and use them as your primary reference."
```

If you add documents later, tell it about them:

```
./tell "I added new files to docs, read them too."
```

Answers are based on the documents first. When something isn't covered by them,
it says so briefly.

---

## Examples of `./tell`

```
./tell "Answer in Romanian."
./tell "Be more detailed, up to 5 sentences."
./tell "For code questions, give just the fixed line."
./tell "What did you answer for the last screenshot? Explain it in more detail."
```

`./tell` prints the answer in the Terminal, so use it for longer explanations.

---

## First-time setup (only once)

macOS asks for some permissions the first time:

| Permission | Where | Why |
|---|---|---|
| **Accessibility** | System Settings → Privacy & Security → Accessibility → turn on **Terminal** | so the program can listen for the § key |
| **Screen Recording** | System Settings → Privacy & Security → Screen Recording → turn on **Terminal** | so it can take screenshots |
| **Notifications** | System Settings → Notifications → **Script Editor** → allow | so answers can appear as notifications |

After turning on a permission, quit Terminal (⌘Q), reopen it, and run `./screen-ask-hotkey` again.

---

## Files in this folder

| File | What it is |
|---|---|
| `screen-ask-hotkey` | the § key listener (start it with `./screen-ask-hotkey`) |
| `tell` | sends a typed message to the session |
| `screen-ask.sh` | takes one screenshot and asks the session (the hotkey runs this) |
| `common.sh` | shared settings: the instructions Claude gets, folders, session handling |
| `hotkey.swift` | source code of the hotkey program |
| `workspace/docs/` | **your reference documents go here** |
| `workspace/answers.log` | every screenshot answer, with date and time |
| `workspace/shots/` | temporary screenshots (deleted after being answered) |

If you edit `hotkey.swift`, rebuild it with:

```
swiftc -swift-version 5 -O hotkey.swift -o screen-ask-hotkey
```

---

## Privacy

- Screenshots are saved here temporarily, sent to **Anthropic's servers** to be answered,
  then deleted from your Mac. Only the answer text stays, in `answers.log`.
- Your documents are also sent to Anthropic when Claude reads them.
- Claude can only **read** files in `workspace/`. It can't edit files or run commands.
- To check whether your chats may be used for training, go to claude.ai → Settings → Privacy.

---

## Troubleshooting

| Problem | Fix |
|---|---|
| Pressing § does nothing | Check Accessibility permission for Terminal, then restart `./screen-ask-hotkey`. |
| Screenshot is just the desktop background | Turn on Screen Recording permission for Terminal. |
| No notifications | Turn on notifications for Script Editor. The answer is still in your clipboard and `answers.log`. |
| Pressing § again doesn't cancel | Press **Esc** instead. |
| "Another request is still running" | A previous request is still being answered. Wait and try again. |
| Error mentioning login or auth | Run `claude` once in Terminal and log in again. |
| Answers ignore the documents | `./tell "Re-read all documents in docs."` or start over with `./tell --new "..."` |
| § can't be typed while the hotkey runs | Expected: the hotkey takes over §. Quit the hotkey (Ctrl+C) to type § again. |
