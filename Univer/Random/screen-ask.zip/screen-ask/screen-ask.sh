#!/bin/zsh
# Screen Ask: select an area of the screen, ask the ongoing Claude session about it,
# get the answer as a notification (full answer also copied to the clipboard).

set -uo pipefail
source "${0:A:h}/common.sh"

notify() {
  # Text is passed as an argument, so quotes in the answer can't break the AppleScript.
  osascript -e 'on run argv' -e 'display notification (item 2 of argv) with title (item 1 of argv)' -e 'end run' "$1" "$2"
}

IMG="shots/shot-$(date +%s)-$$.png"   # unique name, so overlapping runs don't clash

# Drag to select an area (Space picks a window, Esc or § cancels).
screencapture -i "$WORK/$IMG"
[[ -f "$WORK/$IMG" ]] || exit 0

notify "Screen Ask" "Thinking…"

ask "New screenshot: $IMG. If it contains a question, answer it. Otherwise briefly explain what it shows."
STATUS=$?
rm -f "$WORK/$IMG"   # screenshot is not kept after it's been answered

if (( STATUS != 0 )); then
  notify "Screen Ask – error" "${ANSWER:-No answer received}"
  exit 1
fi

print -r -- "$ANSWER" | pbcopy
print -r -- "=== $(date '+%Y-%m-%d %H:%M') ===\n$ANSWER\n" >> "$WORK/answers.log"
notify "Screen Ask (copied to clipboard)" "${ANSWER[1,240]}"
