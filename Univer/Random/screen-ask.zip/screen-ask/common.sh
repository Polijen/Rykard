# Shared settings for Screen Ask. Sourced by screen-ask.sh and tell.
# Everything goes into ONE ongoing Claude session, so it remembers earlier screenshots and instructions.

zmodload zsh/system

CLAUDE=/opt/homebrew/bin/claude
WORK="$HOME/Tools/screen-ask/workspace"   # Claude works in here
DOCS="$WORK/docs"                          # put your reference documents here
SHOTS="$WORK/shots"
SESSION_FILE="$WORK/.session-id"
mkdir -p "$DOCS" "$SHOTS"

SYSTEM_PROMPT="You are Screen Ask, a helper the user talks to through screenshots and short typed messages.
Reference documents are in the ./docs folder. When the user asks you to read them, read them carefully.
Use those documents as your primary reference: base answers on them first, and say briefly when something is not covered by them.
Your replies to screenshots appear in a small notification, so answer in at most 3 short sentences, plain text, no markdown."

# ask "message"  → sets ANSWER, returns non-zero on failure.
ask() {
  cd "$WORK" || return 1
  # One message at a time, so two screenshots can't write to the session at once.
  : >> "$WORK/.lock"
  zsystem flock -t 600 "$WORK/.lock" || { ANSWER="Another request is still running."; return 1; }

  local -a opts=(--allowedTools "Read,Glob,Grep" --append-system-prompt "$SYSTEM_PROMPT")
  local id rc
  if [[ -s $SESSION_FILE ]]; then
    ANSWER=$("$CLAUDE" -p "$1" --resume "$(<$SESSION_FILE)" "${opts[@]}" 2>&1)
    rc=$?
  else
    id=$(uuidgen | tr 'A-Z' 'a-z')
    ANSWER=$("$CLAUDE" -p "$1" --session-id "$id" "${opts[@]}" 2>&1)
    rc=$?
    (( rc == 0 )) && print -r -- "$id" > "$SESSION_FILE"
  fi
  [[ $rc -eq 0 && -n $ANSWER ]]
}
